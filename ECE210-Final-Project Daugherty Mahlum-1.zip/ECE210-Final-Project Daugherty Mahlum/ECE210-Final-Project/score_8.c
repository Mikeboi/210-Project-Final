#include "lab_buttons.h"

const uint8_t score_8_bitmap[] =
{
	// @345 '8' (15 pixels wide)
	0x07, 0xC0, //      #####     
	0x1F, 0xF0, //    #########   
	0x38, 0x38, //   ###     ###  
	0x70, 0x1C, //  ###       ### 
	0x70, 0x1C, //  ###       ### 
	0x70, 0x1C, //  ###       ### 
	0x70, 0x1C, //  ###       ### 
	0x78, 0x3C, //  ####     #### 
	0x38, 0x38, //   ###     ###  
	0x1E, 0xF0, //    #### ####   
	0x0F, 0xE0, //     #######    
	0x0F, 0xE0, //     #######    
	0x3C, 0x78, //   ####   ####  
	0x78, 0x3C, //  ####     #### 
	0x70, 0x1C, //  ###       ### 
	0xE0, 0x0E, // ###         ###
	0xE0, 0x0E, // ###         ###
	0xE0, 0x0E, // ###         ###
	0xE0, 0x0E, // ###         ###
	0x70, 0x1C, //  ###       ### 
	0x78, 0x3C, //  ####     #### 
	0x3F, 0xF8, //   ###########  
	0x0F, 0xE0, //     #######   
};

//* Sizes for the '8' character */
// #define SCORE_8_WIDTH_PXL 15 // copy to header file
// #define SCORE_8_HEIGHT_PXL 24 // copy to header file
