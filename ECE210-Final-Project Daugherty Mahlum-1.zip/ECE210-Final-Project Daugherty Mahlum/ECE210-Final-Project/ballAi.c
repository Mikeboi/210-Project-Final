#include "player.h"
#include "stdlib.h"
#include "Paddle.h"
#define MOVE_PIXELS   	1							// Number of Pixels to move each time.
#define LCD_SIZE_X			240						// X Size of LCD screen in pixels
#define LCD_SIZE_Y			320						// Y Size of LCD screen in pixels
#define LCD_HALF_SIZE_X	LCD_SIZE_X/2	// X center of screen in pixels
#define LCD_HALF_SIZE_Y	LCD_SIZE_Y/2	// Y center of screen in pixels
#define	LCD_INIT_X			LCD_HALF_SIZE_X - PADDLE_WIDTH_PXL/2		// Start image in the center of the screen X
#define	LCD_INIT_Y			LCD_HALF_SIZE_Y - PADDLE_HEIGHT_PXL/2	// Start image in the center of the screen Y
//to check for collisions pulls all x and y cords from other files as well as game mode
extern uint16_t x_pos;
extern uint16_t y_pos;
extern int ball_direction_x;
extern int ball_direction_y;
extern uint16_t p2_y_pos;
extern uint16_t ball_x_pos;
extern uint16_t ball_y_pos;
extern uint16_t com_y_pos;
extern int singleplayer;
extern int multiplayer;
int
ball_update()
{
	uint16_t	width_pixels = PADDLE_WIDTH_PXL;		// width of the imsge in pixels
	uint16_t 	height_pixels = PADDLE_HEIGHT_PXL;	// height of the image in pixels
	//checks y direction 0=down	
	if(ball_direction_y==0){													
      {
        if((ball_y_pos+width_pixels) < LCD_SIZE_Y - MOVE_PIXELS) //sees if ball not at edge of screen before moving
				{
          ece210_lcd_draw_rectangle  (ball_x_pos, width_pixels, ball_y_pos, MOVE_PIXELS, LCD_COLOR_BLACK); 
          ball_y_pos = ball_y_pos + MOVE_PIXELS;																														
        }										
        else //if at edge reverse y component to simulate bounce
				{
				ball_direction_y=1;
				}
      }
		}
	//checks y direction 1=up
   if(ball_direction_y==1){
      {
        if(ball_y_pos > MOVE_PIXELS-1) //sees if ball not at edge of screen before moving														
        {
          ece210_lcd_draw_rectangle  (ball_x_pos, width_pixels, ball_y_pos+width_pixels-MOVE_PIXELS, MOVE_PIXELS, LCD_COLOR_BLACK);
          ball_y_pos = ball_y_pos - MOVE_PIXELS;
        }
				else //if at edge reverse y component to simulate bounce 
				{
				ball_direction_y=0;
				}
      }
		}
	 //checks x direction 0=right
		if(ball_direction_x==0){				
      {		
				//performs two identical checks, one for single player one for multiplayer. This check is to ensure the ball is touching the paddle to be bounced
				if(ball_x_pos+width_pixels == LCD_SIZE_X-width_pixels && (ball_y_pos >= com_y_pos-10 &&  ball_y_pos <= com_y_pos+height_pixels+10)&& singleplayer)
        {
					ball_direction_x=1;
        }
				if(ball_x_pos+width_pixels == LCD_SIZE_X-width_pixels && (ball_y_pos >= p2_y_pos-10 &&  ball_y_pos <= p2_y_pos+height_pixels+10)&& multiplayer)
        {
					ball_direction_x=1;
        }
				else if((ball_x_pos+width_pixels) < LCD_SIZE_X - MOVE_PIXELS) //checks if its not at edge of screen 
				{
          ece210_lcd_draw_rectangle  (ball_x_pos, MOVE_PIXELS, ball_y_pos, width_pixels, LCD_COLOR_BLACK); 
          ball_x_pos = ball_x_pos + MOVE_PIXELS;																														
        }
        else //only case left is edge of screen. So reset ball position, paddle position, and randomize direction for ball.
				{
				ece210_lcd_draw_rectangle  (ball_x_pos, width_pixels, ball_y_pos, width_pixels, LCD_COLOR_BLACK);
				ball_y_pos = LCD_INIT_Y;
	      ball_x_pos = LCD_INIT_Y;
				ball_direction_x = (rand() % (1 - 0 + 1)) + 0;
				ball_direction_y = (rand() % (1 - 0 + 1)) + 0;	
				y_pos=LCD_HALF_SIZE_Y;
				p2_y_pos=LCD_HALF_SIZE_Y;
				com_y_pos=LCD_HALF_SIZE_Y;
				}
      }
		}
	 //checks x direction 0=right
		if(ball_direction_x==1){
      {
				//This check is to ensure the ball is touching the paddle to be bounced
				if(ball_x_pos == width_pixels && ball_y_pos >= y_pos-10 &&  ball_y_pos <= y_pos+height_pixels+10)
        {
					ball_direction_x=0;
        }
				else if(ball_x_pos > MOVE_PIXELS-1) //checks if its not at edge of screen 
        {
          ece210_lcd_draw_rectangle  (ball_x_pos+width_pixels-MOVE_PIXELS, MOVE_PIXELS, ball_y_pos, width_pixels, LCD_COLOR_BLACK);
          ball_x_pos = ball_x_pos - MOVE_PIXELS;
        }
				
				else//only case left is edge of screen. So reset ball position, paddle position, and randomize direction for ball.
				{
				ece210_lcd_draw_rectangle  (ball_x_pos, width_pixels, ball_y_pos, width_pixels, LCD_COLOR_BLACK);
				ball_y_pos = LCD_INIT_Y;
	      ball_x_pos = LCD_INIT_Y;
				ball_direction_x = (rand() % (1 - 0 + 1)) + 0;
				ball_direction_y = (rand() % (1 - 0 + 1)) + 0;	
			  com_y_pos=LCD_HALF_SIZE_Y;
				y_pos=LCD_HALF_SIZE_Y;
				p2_y_pos=LCD_HALF_SIZE_Y;
				}
      }
		}
	  ece210_lcd_draw_image(ball_x_pos,width_pixels, ball_y_pos,width_pixels, paddle_bitmap,LCD_COLOR_WHITE, LCD_COLOR_BLACK); //update ball.
}