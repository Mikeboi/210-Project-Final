#include "lab_buttons.h"

const uint8_t score_7_bitmap[] =
{
	// @299 '7' (15 pixels wide)
	0xFF, 0xFE, // ###############
	0xFF, 0xFE, // ###############
	0x00, 0x0E, //             ###
	0x00, 0x1C, //            ### 
	0x00, 0x1C, //            ### 
	0x00, 0x38, //           ###  
	0x00, 0x38, //           ###  
	0x00, 0x78, //          ####  
	0x00, 0x70, //          ###   
	0x00, 0x70, //          ###   
	0x00, 0xE0, //         ###    
	0x00, 0xE0, //         ###    
	0x01, 0xC0, //        ###     
	0x01, 0xC0, //        ###     
	0x01, 0xC0, //        ###     
	0x03, 0x80, //       ###      
	0x03, 0x80, //       ###      
	0x07, 0x00, //      ###       
	0x07, 0x00, //      ###       
	0x0E, 0x00, //     ###        
	0x0E, 0x00, //     ###        
	0x0E, 0x00, //     ###        
	0x1C, 0x00, //    ###   
};

//* Sizes for the '7' character */
// #define SCORE_7_WIDTH_PXL 15 // copy to header file
// #define SCORE_7_HEIGHT_PXL 24 // copy to header file
