#include "score.h"
#define LCD_SCORE_PLAYER_X 125        // X position of player score
#define LCD_SCORE_PLAYER_Y 20				// Y position of player score
#define LCD_SCORE_COM_X    100        // X position of computer score
#define LCD_SCORE_COM_Y		 20				// Y position of computer score
#define MOVE_PIXELS   	1							// Number of Pixels to move each time.
#define LCD_SIZE_X			240						// X Size of LCD screen in pixels
#define LCD_SIZE_Y			320						// Y Size of LCD screen in pixels
//pull predefined variables from other files
extern int score_com;
extern int score_player;
extern uint16_t ball_x_pos;
extern uint16_t	width_pixels;
extern int singleplayer;
extern int multiplayer;
extern int update;
int erase = 0; //defines a temp variable to run score replacement
int
	Score_update()
{
	// determines if the player has scored a goal, updates the score if they have and runs a mini animation for winning
		if (ball_x_pos+width_pixels == LCD_SIZE_X-MOVE_PIXELS && score_com <= 9)
			{
			++score_com;
			ece210_lcd_draw_rectangle(0, LCD_SIZE_X, 0, LCD_SIZE_Y, LCD_COLOR_BLACK);
			ece210_lcd_print_string("PLAYER 1 SCORES!", 190, 160, LCD_COLOR_WHITE, LCD_COLOR_BLACK);			
			ece210_wait_mSec(3200);	
			ece210_lcd_draw_rectangle(0, LCD_SIZE_X, 0, LCD_SIZE_Y, LCD_COLOR_BLACK);	
			  erase=1;
				if (score_com > 9) {
			ece210_lcd_draw_rectangle(0, LCD_SIZE_X, 0, LCD_SIZE_Y, LCD_COLOR_BLACK);
			 ece210_lcd_print_string("PLAYER 1 WINS!", 190, 160, LCD_COLOR_WHITE, LCD_COLOR_BLACK); 	
			ece210_wait_mSec(3200);	
			ece210_lcd_draw_rectangle(0, LCD_SIZE_X, 0, LCD_SIZE_Y, LCD_COLOR_BLACK);
					score_com = 0;
					score_player=0;
					singleplayer=0;
					update=1;
					multiplayer=0;
					ece210_lcd_draw_rectangle(0,LCD_SIZE_X,0,LCD_SIZE_Y,LCD_COLOR_BLACK);
				}
		}
//these if else statements check the score and update them on the board.			
if (score_com == 0) {
	ece210_lcd_draw_image(LCD_SCORE_COM_X,SCORE_0_WIDTH_PXL, LCD_SCORE_COM_Y,SCORE_0_HEIGHT_PXL, score_0_bitmap,LCD_COLOR_WHITE, LCD_COLOR_BLACK);
} else if (score_com == 1) {
	if (erase)//this wipes the old score so that they dont overlap
	{
	ece210_lcd_draw_image(LCD_SCORE_COM_X,SCORE_0_WIDTH_PXL, LCD_SCORE_COM_Y,SCORE_0_HEIGHT_PXL, score_0_bitmap,LCD_COLOR_BLACK, LCD_COLOR_BLACK);
	erase= 0;
	}
		ece210_lcd_draw_image(LCD_SCORE_COM_X,SCORE_1_WIDTH_PXL, LCD_SCORE_COM_Y,SCORE_1_HEIGHT_PXL, score_1_bitmap,LCD_COLOR_WHITE, LCD_COLOR_BLACK);
} else if (score_com == 2) {
		if (erase)
	{
	ece210_lcd_draw_image(LCD_SCORE_COM_X,SCORE_1_WIDTH_PXL, LCD_SCORE_COM_Y,SCORE_1_HEIGHT_PXL, score_1_bitmap,LCD_COLOR_BLACK, LCD_COLOR_BLACK);
			erase= 0;
	}
	ece210_lcd_draw_image(LCD_SCORE_COM_X,SCORE_2_WIDTH_PXL, LCD_SCORE_COM_Y,SCORE_2_HEIGHT_PXL, score_2_bitmap,LCD_COLOR_WHITE, LCD_COLOR_BLACK);
	} else if (score_com == 3) {
	if (erase)
	{
	ece210_lcd_draw_image(LCD_SCORE_COM_X,SCORE_2_WIDTH_PXL, LCD_SCORE_COM_Y,SCORE_2_HEIGHT_PXL, score_2_bitmap,LCD_COLOR_BLACK, LCD_COLOR_BLACK);
	erase=0;
	}	
		ece210_lcd_draw_image(LCD_SCORE_COM_X,SCORE_3_WIDTH_PXL, LCD_SCORE_COM_Y,SCORE_3_HEIGHT_PXL, score_3_bitmap,LCD_COLOR_WHITE, LCD_COLOR_BLACK);
} else if (score_com == 4) {
		if (erase)
	{
	ece210_lcd_draw_image(LCD_SCORE_COM_X,SCORE_3_WIDTH_PXL, LCD_SCORE_COM_Y,SCORE_3_HEIGHT_PXL, score_3_bitmap,LCD_COLOR_BLACK, LCD_COLOR_BLACK);
	erase=0;
	}
	ece210_lcd_draw_image(LCD_SCORE_COM_X,SCORE_4_WIDTH_PXL, LCD_SCORE_COM_Y,SCORE_4_HEIGHT_PXL, score_4_bitmap,LCD_COLOR_WHITE, LCD_COLOR_BLACK);
} else if (score_com == 5) {
		if (erase)
	{
	ece210_lcd_draw_image(LCD_SCORE_COM_X,SCORE_4_WIDTH_PXL, LCD_SCORE_COM_Y,SCORE_4_HEIGHT_PXL, score_4_bitmap,LCD_COLOR_BLACK, LCD_COLOR_BLACK);
	erase=0;
	}
	ece210_lcd_draw_image(LCD_SCORE_COM_X,SCORE_5_WIDTH_PXL, LCD_SCORE_COM_Y,SCORE_5_HEIGHT_PXL, score_5_bitmap,LCD_COLOR_WHITE, LCD_COLOR_BLACK);
} else if (score_com == 6) {
		if (erase)
	{
	ece210_lcd_draw_image(LCD_SCORE_COM_X,SCORE_5_WIDTH_PXL, LCD_SCORE_COM_Y,SCORE_5_HEIGHT_PXL, score_5_bitmap,LCD_COLOR_BLACK, LCD_COLOR_BLACK);
	erase=0;
	}
	ece210_lcd_draw_image(LCD_SCORE_COM_X,SCORE_6_WIDTH_PXL, LCD_SCORE_COM_Y,SCORE_6_HEIGHT_PXL, score_6_bitmap,LCD_COLOR_WHITE, LCD_COLOR_BLACK);
} else if (score_com == 7) {	
		if (erase)
	{
	ece210_lcd_draw_image(LCD_SCORE_COM_X,SCORE_6_WIDTH_PXL, LCD_SCORE_COM_Y,SCORE_6_HEIGHT_PXL, score_6_bitmap,LCD_COLOR_BLACK, LCD_COLOR_BLACK);
	erase=0;
	}  
	ece210_lcd_draw_image(LCD_SCORE_COM_X,SCORE_7_WIDTH_PXL, LCD_SCORE_COM_Y,SCORE_7_HEIGHT_PXL, score_7_bitmap,LCD_COLOR_WHITE, LCD_COLOR_BLACK);
} else if (score_com == 8) {
  	if (erase)
	{
	ece210_lcd_draw_image(LCD_SCORE_COM_X,SCORE_7_WIDTH_PXL, LCD_SCORE_COM_Y,SCORE_7_HEIGHT_PXL, score_7_bitmap,LCD_COLOR_BLACK, LCD_COLOR_BLACK);
	erase=0;
	}
  ece210_lcd_draw_image(LCD_SCORE_COM_X,SCORE_8_WIDTH_PXL, LCD_SCORE_COM_Y,SCORE_8_HEIGHT_PXL, score_8_bitmap,LCD_COLOR_WHITE, LCD_COLOR_BLACK);
} else if (score_com == 9) {
		if (erase)
	{
	ece210_lcd_draw_image(LCD_SCORE_COM_X,SCORE_8_WIDTH_PXL, LCD_SCORE_COM_Y,SCORE_8_HEIGHT_PXL, score_8_bitmap,LCD_COLOR_BLACK, LCD_COLOR_BLACK);
	erase=0;
	}
  ece210_lcd_draw_image(LCD_SCORE_COM_X,SCORE_9_WIDTH_PXL, LCD_SCORE_COM_Y,SCORE_9_HEIGHT_PXL, score_9_bitmap,LCD_COLOR_WHITE, LCD_COLOR_BLACK);
} 
		
// determines if the com/player2 has scored a goal, updates the score if they have and runs a mini animation for winning
if (ball_x_pos == 0 && score_player <= 9 ) {
			++score_player;
				ece210_lcd_draw_rectangle(0, LCD_SIZE_X, 0, LCD_SIZE_Y, LCD_COLOR_BLACK);
			 ece210_lcd_print_string("PLAYER 2 SCORES!", 190, 160, LCD_COLOR_WHITE, LCD_COLOR_BLACK); 	
			ece210_wait_mSec(3200);	
			ece210_lcd_draw_rectangle(0, LCD_SIZE_X, 0, LCD_SIZE_Y, LCD_COLOR_BLACK);
	    erase=1;
			if (score_player > 9) {
			ece210_lcd_draw_rectangle(0, LCD_SIZE_X, 0, LCD_SIZE_Y, LCD_COLOR_BLACK);
			 ece210_lcd_print_string("PLAYER 2 WINS!", 190, 160, LCD_COLOR_WHITE, LCD_COLOR_BLACK); 	
			ece210_wait_mSec(3200);	
			ece210_lcd_draw_rectangle(0, LCD_SIZE_X, 0, LCD_SIZE_Y, LCD_COLOR_BLACK);
					score_com = 0;
					score_player=0;
					singleplayer=0;
					update=1;
					multiplayer=0;
			}

}
//these if else statements check the score and update them on the board.
			if (score_player == 0) {
	ece210_lcd_draw_image(LCD_SCORE_PLAYER_X,SCORE_0_WIDTH_PXL, LCD_SCORE_PLAYER_Y,SCORE_0_HEIGHT_PXL, score_0_bitmap,LCD_COLOR_WHITE, LCD_COLOR_BLACK);
} else if (score_player == 1) {
	if(erase){
	ece210_lcd_draw_image(LCD_SCORE_PLAYER_X,SCORE_0_WIDTH_PXL, LCD_SCORE_PLAYER_Y,SCORE_0_HEIGHT_PXL, score_0_bitmap,LCD_COLOR_BLACK, LCD_COLOR_BLACK);
  erase=0;
	}
	ece210_lcd_draw_image(LCD_SCORE_PLAYER_X,SCORE_1_WIDTH_PXL, LCD_SCORE_PLAYER_Y,SCORE_1_HEIGHT_PXL, score_1_bitmap,LCD_COLOR_WHITE, LCD_COLOR_BLACK);
} else if (score_player == 2) {
		if(erase){
	ece210_lcd_draw_image(LCD_SCORE_PLAYER_X,SCORE_1_WIDTH_PXL, LCD_SCORE_PLAYER_Y,SCORE_1_HEIGHT_PXL, score_1_bitmap,LCD_COLOR_BLACK, LCD_COLOR_BLACK);
  erase=0;
	}
  ece210_lcd_draw_image(LCD_SCORE_PLAYER_X,SCORE_2_WIDTH_PXL, LCD_SCORE_PLAYER_Y,SCORE_2_HEIGHT_PXL, score_2_bitmap,LCD_COLOR_WHITE, LCD_COLOR_BLACK);
} else if (score_player == 3) {
		if(erase){
	ece210_lcd_draw_image(LCD_SCORE_PLAYER_X,SCORE_2_WIDTH_PXL, LCD_SCORE_PLAYER_Y,SCORE_2_HEIGHT_PXL, score_2_bitmap,LCD_COLOR_BLACK, LCD_COLOR_BLACK);
  erase=0;
	}
  ece210_lcd_draw_image(LCD_SCORE_PLAYER_X,SCORE_3_WIDTH_PXL, LCD_SCORE_PLAYER_Y,SCORE_3_HEIGHT_PXL, score_3_bitmap,LCD_COLOR_WHITE, LCD_COLOR_BLACK);
} else if (score_player == 4) {
		if(erase){
	ece210_lcd_draw_image(LCD_SCORE_PLAYER_X,SCORE_3_WIDTH_PXL, LCD_SCORE_PLAYER_Y,SCORE_3_HEIGHT_PXL, score_3_bitmap,LCD_COLOR_BLACK, LCD_COLOR_BLACK);
  erase=0;
	}
  ece210_lcd_draw_image(LCD_SCORE_PLAYER_X,SCORE_4_WIDTH_PXL, LCD_SCORE_PLAYER_Y,SCORE_4_HEIGHT_PXL, score_4_bitmap,LCD_COLOR_WHITE, LCD_COLOR_BLACK);
} else if (score_player == 5) {
		if(erase){
	ece210_lcd_draw_image(LCD_SCORE_PLAYER_X,SCORE_4_WIDTH_PXL, LCD_SCORE_PLAYER_Y,SCORE_4_HEIGHT_PXL, score_4_bitmap,LCD_COLOR_BLACK, LCD_COLOR_BLACK);
  erase=0;
	}
  ece210_lcd_draw_image(LCD_SCORE_PLAYER_X,SCORE_5_WIDTH_PXL, LCD_SCORE_PLAYER_Y,SCORE_5_HEIGHT_PXL, score_5_bitmap,LCD_COLOR_WHITE, LCD_COLOR_BLACK);
} else if (score_player == 6) {
		if(erase){
	ece210_lcd_draw_image(LCD_SCORE_PLAYER_X,SCORE_5_WIDTH_PXL, LCD_SCORE_PLAYER_Y,SCORE_5_HEIGHT_PXL, score_5_bitmap,LCD_COLOR_BLACK, LCD_COLOR_BLACK);
  erase=0;
	}
  ece210_lcd_draw_image(LCD_SCORE_PLAYER_X,SCORE_6_WIDTH_PXL, LCD_SCORE_PLAYER_Y,SCORE_6_HEIGHT_PXL, score_6_bitmap,LCD_COLOR_WHITE, LCD_COLOR_BLACK);
} else if (score_player == 7) {
		if(erase){
	ece210_lcd_draw_image(LCD_SCORE_PLAYER_X,SCORE_6_WIDTH_PXL, LCD_SCORE_PLAYER_Y,SCORE_6_HEIGHT_PXL, score_6_bitmap,LCD_COLOR_BLACK, LCD_COLOR_BLACK);
  erase=0;
	}
  ece210_lcd_draw_image(LCD_SCORE_PLAYER_X,SCORE_7_WIDTH_PXL, LCD_SCORE_PLAYER_Y,SCORE_7_HEIGHT_PXL, score_7_bitmap,LCD_COLOR_WHITE, LCD_COLOR_BLACK);
} else if (score_player == 8) {
		if(erase){
	ece210_lcd_draw_image(LCD_SCORE_PLAYER_X,SCORE_7_WIDTH_PXL, LCD_SCORE_PLAYER_Y,SCORE_7_HEIGHT_PXL, score_7_bitmap,LCD_COLOR_BLACK, LCD_COLOR_BLACK);
  erase=0;
	}
  ece210_lcd_draw_image(LCD_SCORE_PLAYER_X,SCORE_8_WIDTH_PXL, LCD_SCORE_PLAYER_Y,SCORE_8_HEIGHT_PXL, score_8_bitmap,LCD_COLOR_WHITE, LCD_COLOR_BLACK);
} else if (score_player == 9) {
		if(erase){
	ece210_lcd_draw_image(LCD_SCORE_PLAYER_X,SCORE_8_WIDTH_PXL, LCD_SCORE_PLAYER_Y,SCORE_8_HEIGHT_PXL, score_8_bitmap,LCD_COLOR_BLACK, LCD_COLOR_BLACK);
  erase=0;
	}
  ece210_lcd_draw_image(LCD_SCORE_PLAYER_X,SCORE_9_WIDTH_PXL, LCD_SCORE_PLAYER_Y,SCORE_9_HEIGHT_PXL, score_9_bitmap,LCD_COLOR_WHITE, LCD_COLOR_BLACK);
}
}