
#ifndef __INVADERS_H__
#define __INVADERS_H__

#include "ece210_api.h"

extern const uint8_t paddle_bitmap[];
#define PADDLE_WIDTH_PXL 8
#define PADDLE_HEIGHT_PXL 80

#endif
