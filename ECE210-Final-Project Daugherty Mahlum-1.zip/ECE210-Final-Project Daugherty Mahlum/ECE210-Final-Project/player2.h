#ifndef __Player2_H__
#define __Player2_H__
#include "ece210_api.h"
int player2_update(void);
#endif