#include "lab_buttons.h"

const uint8_t score_2_bitmap[] =
{
	// @69 '2' (16 pixels wide)
	0x03, 0xF0, //       ######    
	0x0F, 0xFC, //     ##########  
	0x1C, 0x1E, //    ###     #### 
	0x38, 0x0E, //   ###       ### 
	0x38, 0x07, //   ###        ###
	0x70, 0x07, //  ###         ###
	0x70, 0x07, //  ###         ###
	0x00, 0x07, //              ###
	0x00, 0x0F, //             ####
	0x00, 0x0E, //             ### 
	0x00, 0x1E, //            #### 
	0x00, 0x3C, //           ####  
	0x00, 0x78, //          ####   
	0x00, 0xF0, //         ####    
	0x03, 0xE0, //       #####     
	0x07, 0xC0, //      #####      
	0x0F, 0x80, //     #####       
	0x1F, 0x00, //    #####        
	0x3C, 0x00, //   ####          
	0x78, 0x00, //  ####           
	0x78, 0x00, //  ####           
	0xFF, 0xFF, // ################
	0xFF, 0xFF, // ################
};

//* Sizes for the '2' character */
// #define SCORE_2_WIDTH_PXL 16 // copy to header file
// #define SCORE_2_HEIGHT_PXL 24 // copy to header file
