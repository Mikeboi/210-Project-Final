#include "lab_buttons.h"

const uint8_t score_3_bitmap[] =
{
	// @115 '3' (15 pixels wide)
	0x0F, 0xC0, //     ######     
	0x3F, 0xF0, //   ##########   
	0x78, 0x78, //  ####    ####  
	0x70, 0x38, //  ###      ###  
	0xE0, 0x1C, // ###        ### 
	0xE0, 0x1C, // ###        ### 
	0x00, 0x1C, //            ### 
	0x00, 0x1C, //            ### 
	0x00, 0x38, //           ###  
	0x00, 0x78, //          ####  
	0x03, 0xE0, //       #####    
	0x03, 0xF8, //       #######  
	0x00, 0x3C, //           #### 
	0x00, 0x1C, //            ### 
	0x00, 0x0E, //             ###
	0x00, 0x0E, //             ###
	0x00, 0x0E, //             ###
	0xE0, 0x0E, // ###         ###
	0xE0, 0x0E, // ###         ###
	0x70, 0x1C, //  ###       ### 
	0x78, 0x38, //  ####     ###  
	0x3F, 0xF0, //   ##########   
	0x0F, 0xC0, //     ######   
};

//* Sizes for the '3' character */
// #define SCORE_3_WIDTH_PXL 15 // copy to header file
// #define SCORE_3_HEIGHT_PXL 24 // copy to header file
