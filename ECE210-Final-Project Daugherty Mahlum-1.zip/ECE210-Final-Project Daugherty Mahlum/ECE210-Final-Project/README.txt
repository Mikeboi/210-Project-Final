Final Project- Michael Daugherty and Brett Mahlum

video demo : https://youtu.be/9BmlLAGvLis

What is the project and how does it work?

Our project is a recreation of Pong. This version has a multiplayer and singleplayer mode,
and plays first to 10 points. 

The project contains all the libraries from the image lab, which we used as our base for our final project
However, we did add our own files in the main src folder.

Most of the code is offsite from the main final and come with their own 
header file (.h) and C file where methods are stored. These have been divided into modules to 
easily see what part of the code affects what part of the game. With that said here is a brief
summery of each C file. For more in depth on the code, see the comments in each C file.

player.c:

This file holds the code to control player 1, or the left Paddle. The code reads any input
from the analog stick and translates that direction into moving the paddle up and down.

Paddle.c:

This file conatins the bitmap of the paddle. It is used for both sides of the screen and
also is the ball. When using it as the ball, we simply used its width for its height to create
a square from the same bitmap.

Player2.c:

When the user selects the multiplayer mode, this file is used to control the right paddle and
acts as a second player. This is done by pressing on the up and down push buttons for their 
corresponding direction.

score_0-9.c:

All 10 of these files are the numbers used in displaying the score. They are initilized 
in the same header file score.h.

score_update.c:

Because bitmaps cannot be stored into arrays, (at least through conventional methods), we opted to
create an algorithim that checks if a player has scored, and updates the score accordingly.
To check if a player has scored, we simply check if the ball's position is the at the edge of 
an x axis. Depending on which side depends on whose score variable is incrimented. We then have
a long chain of if else statements determining which bitmap should be displayed based on these
score variables. 

ball_AI.c:

The ball AI is where most of the code is. the ball has two variables that act as vector directions, 
one for x and one for y. We check if the ball hits either the top or bottom of the screen, if it
is, we reverse the y components direction. For the X component we check if the Ball touches the paddle,
or if it is at the edge of the screen. If it hits the paddle, its x direction is reversed and if it
hits the edge of the screen, it and the paddles' positions are reset. The ball then generates a new
direction and repeats this cycle.

COM.c:

When the user selects the singleplayer mode, this file is used to control the right paddle. 
It's a simple algorithm that simply moves the right paddle from the top to the bottom of the 
screen, revising direction every time it hits the edge.

Main.c:

The Main file acts as the central file that calls each method. First it initilzes the board and 
prompts the user to select a gamemode. Afterwards, it runs the player.c, ball_AI.c, score_update.c
and the COM.c/Player2.c file. After one player wins 10 points, it resets the game and returns to the title screen.


How to run the program.
The program is completly coded, so all you need is a proper KEIL Uvision enviornment that supports the packs to flash
the launchpad. If you have the correct enviornment set up simple

1. extract the zip file.
2. open the uvprojex file under --> ECE210-Final-Project Daugherty Mahlum\ECE210-Final-Project
3. load the program onto the board.

lessons learned: (Michael)

Supprisingly one of the lessons I learned came from setting up the uvision environment. The latest version does not
support flashing with the stellaris ICDI driver and as such, I had to learn about how one flashes to another device
in order to debug and solve the problem. 

I also learned how to code more efficiently and debug the many problems that occured during the development
of this project. Lastly I improved in optimizing my code and finding small shortcuts to cut down on processing power
and assets. 

