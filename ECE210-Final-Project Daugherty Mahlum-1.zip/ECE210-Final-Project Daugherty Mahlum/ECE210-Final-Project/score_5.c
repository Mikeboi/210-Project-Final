#include "lab_buttons.h"

const uint8_t score_5_bitmap[] =
{
		// @207 '5' (15 pixels wide)
	0x3F, 0xFC, //   ############ 
	0x3F, 0xFC, //   ############ 
	0x38, 0x00, //   ###          
	0x38, 0x00, //   ###          
	0x38, 0x00, //   ###          
	0x38, 0x00, //   ###          
	0x70, 0x00, //  ###           
	0x70, 0x00, //  ###           
	0x77, 0xE0, //  ### ######    
	0x7F, 0xF0, //  ###########   
	0x78, 0x38, //  ####     ###  
	0x70, 0x1C, //  ###       ### 
	0x00, 0x1E, //            ####
	0x00, 0x0E, //             ###
	0x00, 0x0E, //             ###
	0x00, 0x0E, //             ###
	0x00, 0x0E, //             ###
	0xE0, 0x0E, // ###         ###
	0xE0, 0x1C, // ###        ### 
	0x70, 0x1C, //  ###       ### 
	0x78, 0x78, //  ####    ####  
	0x3F, 0xF0, //   ##########   
	0x0F, 0xC0, //     ######       
};

//* Sizes for the '5' character */
// #define SCORE_5_WIDTH_PXL 15 // copy to header file
// #define SCORE_5_HEIGHT_PXL 24 // copy to header file
