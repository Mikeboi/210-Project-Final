#include "lab_buttons.h"

const uint8_t score_9_bitmap[] =
{
	// @391 '9' (15 pixels wide)
	0x0F, 0xC0, //     ######     
	0x1F, 0xF0, //    #########   
	0x38, 0x78, //   ###    ####  
	0x70, 0x38, //  ###      ###  
	0x70, 0x1C, //  ###       ### 
	0xE0, 0x1C, // ###        ### 
	0xE0, 0x0E, // ###         ###
	0xE0, 0x0E, // ###         ###
	0xE0, 0x0E, // ###         ###
	0xE0, 0x0E, // ###         ###
	0xF0, 0x0E, // ####        ###
	0x70, 0x1E, //  ###       ####
	0x38, 0x7E, //   ###    ######
	0x1F, 0xEE, //    ######## ###
	0x0F, 0x8E, //     #####   ###
	0x00, 0x0E, //             ###
	0x00, 0x1C, //            ### 
	0xE0, 0x1C, // ###        ### 
	0xE0, 0x1C, // ###        ### 
	0x70, 0x38, //  ###      ###  
	0x78, 0x78, //  ####    ####  
	0x3F, 0xE0, //   #########    
	0x0F, 0xC0, //     ######     
};

//* Sizes for the '9' character */
// #define SCORE_9_WIDTH_PXL 15 // copy to header file
// #define SCORE_9_HEIGHT_PXL 24 // copy to header file
