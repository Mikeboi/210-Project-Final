    #include "player2.h"
		#include "lab_buttons.h"
		#include "Paddle.h"
		#define MOVE_PIXELS   	2							// Number of Pixels to move each time.
#define LCD_SIZE_X			240						// X Size of LCD screen in pixels
#define LCD_SIZE_Y			320						// Y Size of LCD screen in pixels
#define LCD_HALF_SIZE_Y	LCD_SIZE_Y/2	// Y center of screen in pixels
extern uint16_t x_pos;
extern uint16_t y_pos;
uint16_t 	p2_y_pos = LCD_HALF_SIZE_Y;
int
player2_update()
{
	uint8_t 	direction;
	uint16_t	width_pixels = PADDLE_WIDTH_PXL;		// width of the imsge in pixels
	uint16_t 	height_pixels = PADDLE_HEIGHT_PXL;	// height of the image in pixels
  if (AlertButtons)
	{	
		if(btn_down_pressed())
		{
        if((p2_y_pos+height_pixels) < LCD_SIZE_Y-MOVE_PIXELS)	// if not moving past the top edge
        {
          ece210_lcd_draw_rectangle  (230-x_pos, width_pixels, p2_y_pos,  MOVE_PIXELS, LCD_COLOR_BLACK); // erase part of image
          p2_y_pos = p2_y_pos + MOVE_PIXELS;	
        }
      }
    if (btn_up_pressed())
      {
        if(p2_y_pos > MOVE_PIXELS-1)														// if not moving past the bottom edge
        {
          ece210_lcd_draw_rectangle  (230-x_pos, width_pixels, p2_y_pos+height_pixels,  MOVE_PIXELS, LCD_COLOR_BLACK);
          p2_y_pos = p2_y_pos - MOVE_PIXELS;
        }
      }
      }
	ece210_lcd_draw_image(230-x_pos,width_pixels, p2_y_pos,height_pixels, paddle_bitmap,LCD_COLOR_WHITE, LCD_COLOR_BLACK);//update player 2 paddle	
	}
