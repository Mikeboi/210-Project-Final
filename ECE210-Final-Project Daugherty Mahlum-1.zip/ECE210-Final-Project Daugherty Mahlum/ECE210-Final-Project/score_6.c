#include "lab_buttons.h"

const uint8_t score_6_bitmap[] =
{
	// @253 '6' (15 pixels wide)
	0x07, 0xE0, //      ######    
	0x0F, 0xF8, //     #########  
	0x3C, 0x3C, //   ####    #### 
	0x38, 0x1C, //   ###      ### 
	0x70, 0x0E, //  ###        ###
	0x70, 0x0E, //  ###        ###
	0x70, 0x00, //  ###           
	0xE0, 0x00, // ###            
	0xE3, 0xE0, // ###   #####    
	0xEF, 0xF0, // ### ########   
	0xFC, 0x38, // ######    ###  
	0xF0, 0x1C, // ####       ### 
	0xE0, 0x1E, // ###        ####
	0xE0, 0x0E, // ###         ###
	0xE0, 0x0E, // ###         ###
	0xE0, 0x0E, // ###         ###
	0xE0, 0x0E, // ###         ###
	0x70, 0x0E, //  ###        ###
	0x70, 0x1C, //  ###       ### 
	0x38, 0x1C, //   ###      ### 
	0x3C, 0x38, //   ####    ###  
	0x1F, 0xF0, //    #########   
	0x07, 0xE0, //      ######    
};

//* Sizes for the '6' character */
// #define SCORE_6_WIDTH_PXL 15 // copy to header file
// #define SCORE_6_HEIGHT_PXL 24 // copy to header file
