//*****************************************************************************
// main.c
//*****************************************************************************
#include "lab_buttons.h"
#include "player.h"
#include "ballAI.h"
#include "player2.h"
#include "COM.h"
#include "Paddle.h"
#include "score_update.h"
/******************************************************************************
 * Global Constants and Variables
 *****************************************************************************/
#define MOVE_PIXELS   	1							// Number of Pixels to move each time.
#define LCD_SIZE_X			240						// X Size of LCD screen in pixels
#define LCD_SIZE_Y			320						// Y Size of LCD screen in pixels
#define LCD_MAX_DRAW_X	LCD_SIZE_X-1	// 0 to LCD_MAX_DRAW_X is = LCD_SIZE_X
#define LCD_MAX_DRAW_Y	LCD_SIZE_Y-1	// 0 to LCD_MAX_DRAW_Y is = LCD_SIZE_Y
#define LCD_HALF_SIZE_X	LCD_SIZE_X/2	// X center of screen in pixels
#define LCD_HALF_SIZE_Y	LCD_SIZE_Y/2	// Y center of screen in pixels
#define	LCD_INIT_X			LCD_HALF_SIZE_X - PADDLE_WIDTH_PXL/2		// Start image in the center of the screen X
#define	LCD_INIT_Y			LCD_HALF_SIZE_Y - PADDLE_HEIGHT_PXL/2	// Start image in the center of the screen Y
#define LCD_SCORE_PLAYER_X 125        // X position of player score
#define LCD_SCORE_PLAYER_Y 20				// Y position of player score
#define LCD_SCORE_COM_X    100        // X position of computer score
#define LCD_SCORE_COM_Y		 20				// Y position of computer score
uint16_t 	x_pos = 0;		// x_pos holds the x position at the edge of the screen
uint16_t 	y_pos = LCD_INIT_Y;		// y_pos holds the y position of the lower corner of the image
int ball_direction_x=1;         //direction of ball in the x component 
int ball_direction_y=1;         // direction of ball in the y component
// starting cord for ball set to center of screen
uint16_t 	ball_y_pos = LCD_INIT_Y; 
uint16_t 	ball_x_pos = LCD_INIT_X; 
//test variables to use for listening
int singleplayer = 0;
int multiplayer = 0;
int score_player = 0;
int score_com = 0;
int update=0;
//*****************************************************************************
//*****************************************************************************
int 
main(void)
{
  uint16_t	width_pixels = PADDLE_WIDTH_PXL;		// width of the imsge in pixels
	uint16_t 	height_pixels = PADDLE_HEIGHT_PXL;	// height of the image in pixels
	
// set title screen to select game mode
  ece210_initialize_board();
  ece210_lcd_add_msg("Pong\n\r",TERMINAL_ALIGN_CENTER,LCD_COLOR_WHITE);
  ece210_lcd_add_msg("Press left button for singleplayer.",TERMINAL_ALIGN_CENTER,LCD_COLOR_WHITE);
  ece210_lcd_add_msg("Press right button for multiplayer",TERMINAL_ALIGN_CENTER,LCD_COLOR_WHITE);

  
	while(1)
  {		
//determines if the mode is singleplayer or multiplayer
if (update ==1){
	update =0;
	ece210_lcd_draw_rectangle(0,LCD_SIZE_X,0,LCD_SIZE_Y,LCD_COLOR_BLACK);
  ece210_lcd_add_msg("",TERMINAL_ALIGN_LEFT,LCD_COLOR_WHITE);
}
if (AlertButtons)
{
	if(btn_left_pressed()&& singleplayer==0) //left button is single player
	{
		singleplayer = 1;
		ece210_lcd_draw_rectangle(0,LCD_SIZE_X,0,LCD_SIZE_Y,LCD_COLOR_BLACK);
	}
	else if(btn_right_pressed()&& multiplayer==0) //right button is multiplayer
	{
		multiplayer = 1;
		ece210_lcd_draw_rectangle(0,LCD_SIZE_X,0,LCD_SIZE_Y,LCD_COLOR_BLACK);
	}
}	
		
if (singleplayer) //runs singleplayer version 
{	
		//ball AI see file for details
	ball_update();
//computer AI see file for details
		com_update();
//player AI see file for details
		player_update();
//score check and update see file for details.
  Score_update();	
		ece210_lcd_draw_rectangle  (LCD_HALF_SIZE_X, 3, 0, LCD_SIZE_Y, LCD_COLOR_WHITE); //draws a white line at the center of screen for asthetic 
	}
if (multiplayer) //runs multiplayer version
{	
//ball AI see file for details
	ball_update();
//player AI see file for details
		player_update();
// second player AI see file for details
    player2_update();	
//score check and update see file for details.
	Score_update();
		ece210_lcd_draw_rectangle  (LCD_HALF_SIZE_X, 3, 0, LCD_SIZE_Y, LCD_COLOR_WHITE);//draws a white line at the center of screen for asthetic 
	}
  }	// end while 1
}	// end main
