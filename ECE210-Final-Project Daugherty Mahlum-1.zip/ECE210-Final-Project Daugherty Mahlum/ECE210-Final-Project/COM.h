#ifndef __COM_H__
#define __COM_H__
#include "ece210_api.h"
int com_update(void);
#endif