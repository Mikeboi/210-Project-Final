#include "lab_buttons.h"

const uint8_t score_4_bitmap[] =
{
  // @161 '4' (16 pixels wide)
	0x00, 0x38, //           ###   
	0x00, 0x38, //           ###   
	0x00, 0x78, //          ####   
	0x00, 0xF8, //         #####   
	0x00, 0xF8, //         #####   
	0x01, 0xB8, //        ## ###   
	0x03, 0xB8, //       ### ###   
	0x03, 0x38, //       ##  ###   
	0x06, 0x38, //      ##   ###   
	0x0E, 0x38, //     ###   ###   
	0x0C, 0x38, //     ##    ###   
	0x18, 0x38, //    ##     ###   
	0x38, 0x38, //   ###     ###   
	0x30, 0x38, //   ##      ###   
	0x60, 0x38, //  ##       ###   
	0xE0, 0x38, // ###       ###   
	0xFF, 0xFF, // ################
	0xFF, 0xFF, // ################
	0x00, 0x38, //           ###   
	0x00, 0x38, //           ###   
	0x00, 0x38, //           ###   
	0x00, 0x38, //           ###   
	0x00, 0x38, //           ###   
};

//* Sizes for the '4' character */
// #define SCORE_4_WIDTH_PXL 16 // copy to header file
// #define SCORE_4_HEIGHT_PXL 24 // copy to header file
