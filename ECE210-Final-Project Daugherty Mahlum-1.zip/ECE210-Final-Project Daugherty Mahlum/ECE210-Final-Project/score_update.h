#ifndef __SCORE_UPDATE_H__
#define __SCORE_UPDATE_H__
#include "ece210_api.h"
int Score_update(void);
#endif