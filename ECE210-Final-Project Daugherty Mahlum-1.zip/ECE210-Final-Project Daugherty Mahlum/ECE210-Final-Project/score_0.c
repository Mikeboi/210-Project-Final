#include "lab_buttons.h"

const uint8_t score_0_bitmap[] =
{
	0x07, 0xC0, //      #####     
	0x1F, 0xF0, //    #########   
	0x3C, 0x78, //   ####   ####  
	0x38, 0x38, //   ###     ###  
	0x70, 0x1C, //  ###       ### 
	0x70, 0x1C, //  ###       ### 
	0xE0, 0x0E, // ###         ###
	0xE0, 0x0E, // ###         ###
	0xE0, 0x0E, // ###         ###
	0xE0, 0x0E, // ###         ###
	0xE0, 0x0E, // ###         ###
	0xE0, 0x0E, // ###         ###
	0xE0, 0x0E, // ###         ###
	0xE0, 0x0E, // ###         ###
	0xE0, 0x0E, // ###         ###
	0xE0, 0x0E, // ###         ###
	0xE0, 0x0E, // ###         ###
	0x70, 0x1C, //  ###       ### 
	0x70, 0x1C, //  ###       ### 
	0x38, 0x38, //   ###     ###  
	0x3C, 0x78, //   ####   ####  
	0x1F, 0xF0, //    #########   
	0x07, 0xC0, //      #####   
};

//* Sizes for the '0' character */
// #define SCORE_0_WIDTH_PXL 15 // copy to header file
// #define SCORE_0_HEIGHT_PXL 24 // copy to header file
