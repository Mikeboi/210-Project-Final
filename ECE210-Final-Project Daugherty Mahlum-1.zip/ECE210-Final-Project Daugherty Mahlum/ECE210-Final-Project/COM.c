  #include "COM.h"
	#include "Paddle.h"	
	#define MOVE_PIXELS   	2							// Number of Pixels to move each time.
#define LCD_SIZE_X			240						// X Size of LCD screen in pixels
#define LCD_SIZE_Y			320						// Y Size of LCD screen in pixels
extern uint16_t x_pos;
  uint16_t	width_pixels = PADDLE_WIDTH_PXL;		// width of the imsge in pixels
	uint16_t 	height_pixels = PADDLE_HEIGHT_PXL;	// height of the image in pixels
  int com_direction=0; //variable to determine if com moves up or down
	uint16_t 	com_y_pos = 0; //COM starts at top of screen
int
	com_update(void)
	{
				if(com_direction==0){													// moving down
      {
        if((com_y_pos+height_pixels) < LCD_SIZE_Y - MOVE_PIXELS)	//checks if paddle is 
				{
          ece210_lcd_draw_rectangle  (230-x_pos, width_pixels, com_y_pos,  MOVE_PIXELS, LCD_COLOR_BLACK); 
          com_y_pos = com_y_pos + MOVE_PIXELS;																														
        }										
        else
				{
				com_direction=1;
				}
      }
		}
   else if(com_direction==1){   //moving up
      {
        if(com_y_pos > MOVE_PIXELS-1)														
        {
          ece210_lcd_draw_rectangle  (230-x_pos, width_pixels, com_y_pos+height_pixels,  MOVE_PIXELS, LCD_COLOR_BLACK);
          com_y_pos = com_y_pos - MOVE_PIXELS;
        }
				else
				{
				com_direction=0;
				}
      }
		}
	 ece210_lcd_draw_image(230-x_pos,width_pixels, com_y_pos,height_pixels, paddle_bitmap,LCD_COLOR_WHITE, LCD_COLOR_BLACK); //update computer paddle
	}