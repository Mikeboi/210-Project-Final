#include "player.h"
		#include "lab_buttons.h"
		#include "Paddle.h"
		#define MOVE_PIXELS   	2							// Number of Pixels to move each time.
#define LCD_SIZE_X			240						// X Size of LCD screen in pixels
#define LCD_SIZE_Y			320						// Y Size of LCD screen in pixels
extern uint16_t x_pos;//pulls the players position for x as defined in main
extern uint16_t y_pos;//pulls the players position for y as defined in main
int
player_update()
{
	uint8_t 	direction;
	uint16_t	width_pixels = PADDLE_WIDTH_PXL;		// width of the imsge in pixels
	uint16_t 	height_pixels = PADDLE_HEIGHT_PXL;	// height of the image in pixels
	direction = ece210_ps2_read_position();		// Joystick function to read digital value of x or Y pointing.	
	switch (direction)												// based on the joystick direction move the image.
    {
      case PS2_DOWN:
      {
        if((y_pos+height_pixels) < LCD_SIZE_Y-MOVE_PIXELS)	// checks if paddle is above bottum of screen before moving
        {
          ece210_lcd_draw_rectangle  (x_pos, width_pixels, y_pos, MOVE_PIXELS, LCD_COLOR_BLACK);
          y_pos = y_pos + MOVE_PIXELS;
        }
        break;
      }
      case PS2_UP:
      {
        if(y_pos > MOVE_PIXELS-1)														// checks if paddle is below top of screen before moving
        {
          ece210_lcd_draw_rectangle  (x_pos, width_pixels, y_pos+height_pixels-MOVE_PIXELS, MOVE_PIXELS, LCD_COLOR_BLACK);
          y_pos = y_pos - MOVE_PIXELS;
        }
        break;
      }
      case PS2_CENTER:
      {
        // Do nothing
        break;
      }
      default:
      {
        break;
      }
    }	// end switch
		
	ece210_lcd_draw_image(x_pos,width_pixels, y_pos,height_pixels, paddle_bitmap,LCD_COLOR_WHITE, LCD_COLOR_BLACK); //update player paddle
	}