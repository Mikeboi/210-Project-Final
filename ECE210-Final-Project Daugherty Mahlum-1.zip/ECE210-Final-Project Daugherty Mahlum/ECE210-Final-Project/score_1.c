#include "lab_buttons.h"

const uint8_t score_1_bitmap[] =
{
	// @46 '1' (8 pixels wide)
	0x03, //       ##
	0x07, //      ###
	0x0F, //     ####
	0x1F, //    #####
	0xFF, // ########
	0xF7, // #### ###
	0x07, //      ###
	0x07, //      ###
	0x07, //      ###
	0x07, //      ###
	0x07, //      ###
	0x07, //      ###
	0x07, //      ###
	0x07, //      ###
	0x07, //      ###
	0x07, //      ###
	0x07, //      ###
	0x07, //      ###
	0x07, //      ###
	0x07, //      ###
	0x07, //      ###
	0x07, //      ###
	0x07, //      ###
};

//* Sizes for the '1' character */
// #define SCORE_1_WIDTH_PXL 8 // copy to header file
// #define SCORE_1_HEIGHT_PXL 24 // copy to header file
