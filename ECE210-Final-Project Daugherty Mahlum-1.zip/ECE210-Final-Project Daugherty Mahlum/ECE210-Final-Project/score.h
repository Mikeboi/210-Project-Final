#ifndef __PADDLE_H__
#define __PADDLE_H__

#include "ece210_api.h"

extern const uint8_t score_0_bitmap[];
#define SCORE_0_WIDTH_PXL 15
#define SCORE_0_HEIGHT_PXL 23
extern const uint8_t score_1_bitmap[];
#define SCORE_1_WIDTH_PXL 8
#define SCORE_1_HEIGHT_PXL 24
extern const uint8_t score_2_bitmap[];
#define SCORE_2_WIDTH_PXL 16
#define SCORE_2_HEIGHT_PXL 23
extern const uint8_t score_3_bitmap[];
#define SCORE_3_WIDTH_PXL 15
#define SCORE_3_HEIGHT_PXL 23
extern const uint8_t score_4_bitmap[];
#define SCORE_4_WIDTH_PXL 16
#define SCORE_4_HEIGHT_PXL 23
extern const uint8_t score_5_bitmap[];
#define SCORE_5_WIDTH_PXL 15
#define SCORE_5_HEIGHT_PXL 23
extern const uint8_t score_6_bitmap[];
#define SCORE_6_WIDTH_PXL 15
#define SCORE_6_HEIGHT_PXL 23
extern const uint8_t score_7_bitmap[];
#define SCORE_7_WIDTH_PXL 15
#define SCORE_7_HEIGHT_PXL 23
extern const uint8_t score_8_bitmap[];
#define SCORE_8_WIDTH_PXL 15
#define SCORE_8_HEIGHT_PXL 24
extern const uint8_t score_9_bitmap[];
#define SCORE_9_WIDTH_PXL 15
#define SCORE_9_HEIGHT_PXL 24

#endif